const express = require('express');
const { join } = require('path');
const fs = require('fs');

const app = express();
const port = 3001;

app.get('/', (_req, res) => {
  res.send('Hello World!');
});

app.get('/download', (_req, res) => {
  const content = fs.readFileSync(join(__dirname, 'file-to-download.zip'), 'utf8');
  console.log(content);

  res
    .download(
      content,
      'download.zip',
      (error) => {
        if (error) {
          console.error('Error downloading file: >>>', error);
        } else {
          console.info('File downloaded!');
        }
      },
    );
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
